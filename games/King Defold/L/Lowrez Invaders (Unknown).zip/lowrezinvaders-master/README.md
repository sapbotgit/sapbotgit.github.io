# Lowrez Invaders
Simple Space Invaders clone with a 64x64 pixel resolution for the [Lowrezjam 2016](http://gamejolt.com/tag/lowrezjam)

Made using the [Defold game engine](http://www.defold.com)
# Play it!
Try the game here: http://britzl.github.io/lowrezinvaders/
