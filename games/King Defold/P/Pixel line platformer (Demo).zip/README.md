# Pixel Line Platformer sample
Defold sample project for a platformer game.

![](/docs/screenshot.png)

# Demo
Try the HTML5 demo here: https://defold.com/sample-pixel-line-platformer/

# Credits
* Graphics - [Pixel Line Platformer](https://kenney.nl/assets/pixel-line-platformer) by [Kenney](https://kenney.nl)
* Font - Kenney Pixel from [Kenney Fonts](https://kenney.nl/assets/kenney-fonts) by [Kenney](https://kenney.nl)
